use motor_math::{Rect, Vec2};

/// Bir polyline'ın alt bölüm sayısı için üst sınır.
const MAX_SEGMENTS: usize = 10_000;

/// `a*t² + b*t + c = 0` köklerini döner (gerçek olanlar).
fn solve_quadratic(a: f64, b: f64, c: f64) -> ([f64; 2], usize) {
    if a.abs() < 1e-12 {
        if b.abs() < 1e-12 {
            return ([0.0; 2], 0);
        }
        return ([-c / b, 0.0], 1);
    }
    let disc = b * b - 4.0 * a * c;
    if disc < 0.0 {
        return ([0.0; 2], 0);
    }
    let sq = disc.sqrt();
    ([(-b - sq) / (2.0 * a), (-b + sq) / (2.0 * a)], 2)
}

/// Kuadratik Bézier eğrisi.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct QuadBez {
    pub p0: Vec2,
    pub p1: Vec2,
    pub p2: Vec2,
}

impl QuadBez {
    pub fn new(p0: Vec2, p1: Vec2, p2: Vec2) -> Self {
        QuadBez { p0, p1, p2 }
    }

    pub fn eval(&self, t: f64) -> Vec2 {
        let mt = 1.0 - t;
        self.p0 * (mt * mt) + self.p1 * (2.0 * mt * t) + self.p2 * (t * t)
    }

    /// De Casteljau ile `t` noktasından ikiye böler.
    pub fn subdivide(&self, t: f64) -> (QuadBez, QuadBez) {
        let a = self.p0.lerp(self.p1, t);
        let b = self.p1.lerp(self.p2, t);
        let m = a.lerp(b, t);
        (QuadBez::new(self.p0, a, m), QuadBez::new(m, b, self.p2))
    }

    /// Tam (sıkı) sınırlayıcı kutu.
    pub fn bounding_box(&self) -> Rect {
        let mut r = Rect::EMPTY.union_pt(self.p0).union_pt(self.p2);
        let axes = [
            (self.p0.x, self.p1.x, self.p2.x),
            (self.p0.y, self.p1.y, self.p2.y),
        ];
        for (a, b, c) in axes {
            let denom = a - 2.0 * b + c;
            if denom.abs() > 1e-12 {
                let t = (a - b) / denom;
                if t > 0.0 && t < 1.0 {
                    r = r.union_pt(self.eval(t));
                }
            }
        }
        r
    }

    /// Eğriyi çizgi parçalarına böler. Başlangıç noktası `out`'a EKLENMEZ
    /// (çağıran zaten eklemiş olmalı); bitiş noktası eklenir.
    pub fn flatten_into(&self, tolerance: f64, out: &mut Vec<Vec2>) {
        // Hata üst sınırı: |p0 - 2p1 + p2| / (4 n²) <= tolerance
        let dd = (self.p0 - self.p1 * 2.0 + self.p2).length();
        let n = ((dd / (4.0 * tolerance)).sqrt().ceil() as usize).clamp(1, MAX_SEGMENTS);
        for i in 1..=n {
            out.push(self.eval(i as f64 / n as f64));
        }
    }
}

/// Kübik Bézier eğrisi.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct CubicBez {
    pub p0: Vec2,
    pub p1: Vec2,
    pub p2: Vec2,
    pub p3: Vec2,
}

impl CubicBez {
    pub fn new(p0: Vec2, p1: Vec2, p2: Vec2, p3: Vec2) -> Self {
        CubicBez { p0, p1, p2, p3 }
    }

    pub fn eval(&self, t: f64) -> Vec2 {
        let mt = 1.0 - t;
        self.p0 * (mt * mt * mt)
            + self.p1 * (3.0 * mt * mt * t)
            + self.p2 * (3.0 * mt * t * t)
            + self.p3 * (t * t * t)
    }

    /// De Casteljau ile `t` noktasından ikiye böler.
    pub fn subdivide(&self, t: f64) -> (CubicBez, CubicBez) {
        let a = self.p0.lerp(self.p1, t);
        let b = self.p1.lerp(self.p2, t);
        let c = self.p2.lerp(self.p3, t);
        let ab = a.lerp(b, t);
        let bc = b.lerp(c, t);
        let m = ab.lerp(bc, t);
        (
            CubicBez::new(self.p0, a, ab, m),
            CubicBez::new(m, bc, c, self.p3),
        )
    }

    /// Tam (sıkı) sınırlayıcı kutu: türevin köklerinde ekstremum aranır.
    pub fn bounding_box(&self) -> Rect {
        let mut r = Rect::EMPTY.union_pt(self.p0).union_pt(self.p3);
        let axes = [
            (self.p0.x, self.p1.x, self.p2.x, self.p3.x),
            (self.p0.y, self.p1.y, self.p2.y, self.p3.y),
        ];
        for (a0, a1, a2, a3) in axes {
            let qa = 3.0 * (-a0 + 3.0 * a1 - 3.0 * a2 + a3);
            let qb = 6.0 * (a0 - 2.0 * a1 + a2);
            let qc = 3.0 * (a1 - a0);
            let (roots, n) = solve_quadratic(qa, qb, qc);
            for &t in roots.iter().take(n) {
                if t > 0.0 && t < 1.0 {
                    r = r.union_pt(self.eval(t));
                }
            }
        }
        r
    }

    /// Eğriyi çizgi parçalarına böler. Başlangıç noktası `out`'a EKLENMEZ;
    /// bitiş noktası eklenir.
    pub fn flatten_into(&self, tolerance: f64, out: &mut Vec<Vec2>) {
        // Hata üst sınırı: 0.75 * dd / n² <= tolerance
        let d1 = (self.p0 - self.p1 * 2.0 + self.p2).length();
        let d2 = (self.p1 - self.p2 * 2.0 + self.p3).length();
        let dd = d1.max(d2);
        let n = ((0.75 * dd / tolerance).sqrt().ceil() as usize).clamp(1, MAX_SEGMENTS);
        for i in 1..=n {
            out.push(self.eval(i as f64 / n as f64));
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn v(x: f64, y: f64) -> Vec2 {
        Vec2::new(x, y)
    }

    #[test]
    fn quad_bbox_includes_extremum() {
        // Tepe noktası t=0.5'te, y = 1.0
        let q = QuadBez::new(v(0.0, 0.0), v(1.0, 2.0), v(2.0, 0.0));
        let b = q.bounding_box();
        assert!((b.y1 - 1.0).abs() < 1e-9);
        assert!((b.x0 - 0.0).abs() < 1e-9 && (b.x1 - 2.0).abs() < 1e-9);
    }

    #[test]
    fn cubic_bbox_matches_dense_sampling() {
        let c = CubicBez::new(v(0.0, 0.0), v(10.0, 30.0), v(-5.0, -20.0), v(8.0, 4.0));
        let b = c.bounding_box();
        let mut s = Rect::EMPTY;
        for i in 0..=10_000 {
            s = s.union_pt(c.eval(i as f64 / 10_000.0));
        }
        assert!((b.x0 - s.x0).abs() < 1e-3 && (b.x1 - s.x1).abs() < 1e-3);
        assert!((b.y0 - s.y0).abs() < 1e-3 && (b.y1 - s.y1).abs() < 1e-3);
    }

    #[test]
    fn subdivide_is_continuous() {
        let c = CubicBez::new(v(0.0, 0.0), v(1.0, 2.0), v(3.0, 2.0), v(4.0, 0.0));
        let (l, r) = c.subdivide(0.3);
        assert!((l.p3 - r.p0).length() < 1e-12);
        assert!((l.p3 - c.eval(0.3)).length() < 1e-12);
    }

    #[test]
    fn flatten_ends_exactly_and_stays_close() {
        let c = CubicBez::new(v(0.0, 0.0), v(0.0, 100.0), v(100.0, 100.0), v(100.0, 0.0));
        let mut pts = vec![c.p0];
        c.flatten_into(0.1, &mut pts);
        assert!(pts.len() > 3);
        assert_eq!(*pts.last().unwrap(), c.p3);
        // Her parça ortası, gerçek eğriye tolerans içinde olmalı (kabaca).
        let n = pts.len() - 1;
        for i in 0..n {
            let mid = pts[i].lerp(pts[i + 1], 0.5);
            let t = (i as f64 + 0.5) / n as f64;
            assert!((mid - c.eval(t)).length() < 0.2);
        }
    }

    #[test]
    fn degenerate_curve_flattens_to_one_segment() {
        let p = v(5.0, 5.0);
        let mut pts = vec![p];
        CubicBez::new(p, p, p, p).flatten_into(0.1, &mut pts);
        assert_eq!(pts.len(), 2);
    }
}
