use crate::bezier::{CubicBez, QuadBez};
use motor_math::{Affine, Rect, Vec2};

/// Yol elemanı (SVG/PostScript modeli).
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum PathEl {
    MoveTo(Vec2),
    LineTo(Vec2),
    QuadTo(Vec2, Vec2),
    CurveTo(Vec2, Vec2, Vec2),
    ClosePath,
}

/// Düzleştirilmiş (sadece doğru parçalarından oluşan) alt yol.
#[derive(Clone, Debug, PartialEq)]
pub struct Polyline {
    pub points: Vec<Vec2>,
    pub closed: bool,
}

/// Bir veya daha fazla alt yoldan oluşan vektör yolu.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct Path {
    els: Vec<PathEl>,
}

fn flush(out: &mut Vec<Polyline>, pts: &mut Vec<Vec2>, closed: bool) {
    if closed && pts.len() > 1 && pts.first() == pts.last() {
        pts.pop();
    }
    if pts.len() >= 2 {
        out.push(Polyline {
            points: std::mem::take(pts),
            closed,
        });
    } else {
        pts.clear();
    }
}

fn ensure_start(pts: &mut Vec<Vec2>, cur: Vec2) {
    if pts.is_empty() {
        pts.push(cur);
    }
}

impl Path {
    pub fn new() -> Self {
        Path::default()
    }

    pub fn elements(&self) -> &[PathEl] {
        &self.els
    }

    pub fn is_empty(&self) -> bool {
        self.els.is_empty()
    }

    pub fn move_to(&mut self, p: Vec2) -> &mut Self {
        self.els.push(PathEl::MoveTo(p));
        self
    }

    pub fn line_to(&mut self, p: Vec2) -> &mut Self {
        self.els.push(PathEl::LineTo(p));
        self
    }

    pub fn quad_to(&mut self, p1: Vec2, p2: Vec2) -> &mut Self {
        self.els.push(PathEl::QuadTo(p1, p2));
        self
    }

    pub fn curve_to(&mut self, p1: Vec2, p2: Vec2, p3: Vec2) -> &mut Self {
        self.els.push(PathEl::CurveTo(p1, p2, p3));
        self
    }

    pub fn close(&mut self) -> &mut Self {
        self.els.push(PathEl::ClosePath);
        self
    }

    /// Dikdörtgen yolu.
    pub fn rect(r: Rect) -> Path {
        let mut p = Path::new();
        p.move_to(Vec2::new(r.x0, r.y0))
            .line_to(Vec2::new(r.x1, r.y0))
            .line_to(Vec2::new(r.x1, r.y1))
            .line_to(Vec2::new(r.x0, r.y1))
            .close();
        p
    }

    /// 4 kübik Bézier ile daire yaklaşıklığı (hata ~ yarıçapın %0.03'ü).
    pub fn circle(center: Vec2, radius: f64) -> Path {
        const KAPPA: f64 = 0.552_284_749_830_793_6;
        let (cx, cy, r) = (center.x, center.y, radius);
        let k = KAPPA * r;
        let v = Vec2::new;
        let mut p = Path::new();
        p.move_to(v(cx + r, cy))
            .curve_to(v(cx + r, cy + k), v(cx + k, cy + r), v(cx, cy + r))
            .curve_to(v(cx - k, cy + r), v(cx - r, cy + k), v(cx - r, cy))
            .curve_to(v(cx - r, cy - k), v(cx - k, cy - r), v(cx, cy - r))
            .curve_to(v(cx + k, cy - r), v(cx + r, cy - k), v(cx + r, cy))
            .close();
        p
    }

    /// Tüm noktalara dönüşümü uygulayarak yeni bir yol üretir.
    pub fn transform(&self, m: &Affine) -> Path {
        let els = self
            .els
            .iter()
            .map(|el| match *el {
                PathEl::MoveTo(p) => PathEl::MoveTo(m.transform_point(p)),
                PathEl::LineTo(p) => PathEl::LineTo(m.transform_point(p)),
                PathEl::QuadTo(a, b) => {
                    PathEl::QuadTo(m.transform_point(a), m.transform_point(b))
                }
                PathEl::CurveTo(a, b, c) => PathEl::CurveTo(
                    m.transform_point(a),
                    m.transform_point(b),
                    m.transform_point(c),
                ),
                PathEl::ClosePath => PathEl::ClosePath,
            })
            .collect();
        Path { els }
    }

    /// Sıkı sınırlayıcı kutu. Çizim yapan eleman yoksa `Rect::EMPTY` döner.
    /// Tek başına `MoveTo` kutuya katkı yapmaz.
    pub fn bounding_box(&self) -> Rect {
        let mut r = Rect::EMPTY;
        let mut cur: Option<Vec2> = None;
        let mut start = Vec2::ZERO;
        for el in &self.els {
            match *el {
                PathEl::MoveTo(p) => {
                    cur = Some(p);
                    start = p;
                }
                PathEl::LineTo(p) => {
                    r = r.union_pt(cur.unwrap_or(p)).union_pt(p);
                    cur = Some(p);
                }
                PathEl::QuadTo(p1, p2) => {
                    let c = cur.unwrap_or(p2);
                    r = r.union(&QuadBez::new(c, p1, p2).bounding_box());
                    cur = Some(p2);
                }
                PathEl::CurveTo(p1, p2, p3) => {
                    let c = cur.unwrap_or(p3);
                    r = r.union(&CubicBez::new(c, p1, p2, p3).bounding_box());
                    cur = Some(p3);
                }
                PathEl::ClosePath => {
                    if cur.is_some() {
                        cur = Some(start);
                    }
                }
            }
        }
        r
    }

    /// Eğrileri `tolerance` hata sınırıyla düz parçalara böler.
    ///
    /// Başında `MoveTo` olmayan yollarda ilk çizim elemanı `MoveTo` gibi ele alınır.
    pub fn flatten(&self, tolerance: f64) -> Vec<Polyline> {
        let tol = tolerance.max(1e-9);
        let mut out = Vec::new();
        let mut pts: Vec<Vec2> = Vec::new();
        let mut start = Vec2::ZERO;
        let mut cur: Option<Vec2> = None;

        for &raw in &self.els {
            let el = match (raw, cur) {
                (PathEl::LineTo(p), None)
                | (PathEl::QuadTo(_, p), None)
                | (PathEl::CurveTo(_, _, p), None) => PathEl::MoveTo(p),
                (e, _) => e,
            };
            match el {
                PathEl::MoveTo(p) => {
                    flush(&mut out, &mut pts, false);
                    start = p;
                    cur = Some(p);
                    pts.push(p);
                }
                PathEl::LineTo(p) => {
                    let c = cur.unwrap_or(p);
                    ensure_start(&mut pts, c);
                    pts.push(p);
                    cur = Some(p);
                }
                PathEl::QuadTo(p1, p2) => {
                    let c = cur.unwrap_or(p2);
                    ensure_start(&mut pts, c);
                    QuadBez::new(c, p1, p2).flatten_into(tol, &mut pts);
                    cur = Some(p2);
                }
                PathEl::CurveTo(p1, p2, p3) => {
                    let c = cur.unwrap_or(p3);
                    ensure_start(&mut pts, c);
                    CubicBez::new(c, p1, p2, p3).flatten_into(tol, &mut pts);
                    cur = Some(p3);
                }
                PathEl::ClosePath => {
                    if let Some(c) = cur {
                        ensure_start(&mut pts, c);
                        flush(&mut out, &mut pts, true);
                        cur = Some(start);
                    }
                }
            }
        }
        flush(&mut out, &mut pts, false);
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn v(x: f64, y: f64) -> Vec2 {
        Vec2::new(x, y)
    }

    #[test]
    fn rect_path_bbox_and_flatten() {
        let r = Rect::new(1.0, 2.0, 5.0, 8.0);
        let p = Path::rect(r);
        assert_eq!(p.bounding_box(), r);
        let polys = p.flatten(0.1);
        assert_eq!(polys.len(), 1);
        assert!(polys[0].closed);
        assert_eq!(polys[0].points.len(), 4);
    }

    #[test]
    fn circle_bbox_is_exact() {
        let p = Path::circle(v(10.0, -3.0), 5.0);
        let b = p.bounding_box();
        assert!((b.x0 - 5.0).abs() < 1e-9 && (b.x1 - 15.0).abs() < 1e-9);
        assert!((b.y0 + 8.0).abs() < 1e-9 && (b.y1 - 2.0).abs() < 1e-9);
    }

    #[test]
    fn circle_flatten_points_near_radius() {
        let c = v(0.0, 0.0);
        let p = Path::circle(c, 50.0);
        let polys = p.flatten(0.05);
        assert_eq!(polys.len(), 1);
        for pt in &polys[0].points {
            assert!((pt.length() - 50.0).abs() < 0.1);
        }
    }

    #[test]
    fn transform_moves_bbox() {
        let p = Path::rect(Rect::new(0.0, 0.0, 2.0, 2.0));
        let q = p.transform(&Affine::translate(v(10.0, 20.0)));
        assert_eq!(q.bounding_box(), Rect::new(10.0, 20.0, 12.0, 22.0));
    }

    #[test]
    fn multiple_subpaths() {
        let mut p = Path::new();
        p.move_to(v(0.0, 0.0)).line_to(v(1.0, 0.0));
        p.move_to(v(5.0, 5.0)).line_to(v(6.0, 5.0)).line_to(v(6.0, 6.0));
        let polys = p.flatten(0.1);
        assert_eq!(polys.len(), 2);
        assert_eq!(polys[0].points.len(), 2);
        assert_eq!(polys[1].points.len(), 3);
        assert!(!polys[0].closed && !polys[1].closed);
    }

    #[test]
    fn lone_move_to_is_ignored() {
        let mut p = Path::new();
        p.move_to(v(3.0, 3.0));
        assert!(p.bounding_box().is_empty());
        assert!(p.flatten(0.1).is_empty());
    }

    #[test]
    fn drawing_after_close_starts_new_subpath_at_start() {
        let mut p = Path::new();
        p.move_to(v(0.0, 0.0))
            .line_to(v(4.0, 0.0))
            .line_to(v(4.0, 4.0))
            .close()
            .line_to(v(0.0, 9.0));
        let polys = p.flatten(0.1);
        assert_eq!(polys.len(), 2);
        assert!(polys[0].closed);
        assert_eq!(polys[1].points, vec![v(0.0, 0.0), v(0.0, 9.0)]);
    }
}
