use crate::FillRule;
use motor_math::Vec2;
use motor_path::Polyline;

/// Aşağı doğru (y artan) normalize edilmiş kenar: `y0 < y1`.
#[derive(Clone, Copy, Debug)]
pub(crate) struct Edge {
    pub x0: f64,
    pub y0: f64,
    pub x1: f64,
    pub y1: f64,
    /// Orijinal yön: y artıyorsa +1, azalıyorsa -1.
    pub dir: i32,
}

impl Edge {
    /// Yarı açık aralık `[y0, y1)`: köşelerde çift sayım olmaz.
    pub(crate) fn covers(&self, y: f64) -> bool {
        y >= self.y0 && y < self.y1
    }

    pub(crate) fn x_at(&self, y: f64) -> f64 {
        self.x0 + (y - self.y0) * (self.x1 - self.x0) / (self.y1 - self.y0)
    }
}

/// Tüm alt yolların kenarlarını toplar (her alt yol örtük olarak kapatılır).
/// Yatay ve sonlu olmayan kenarlar atlanır.
pub(crate) fn collect_edges(polys: &[Polyline]) -> Vec<Edge> {
    let mut edges = Vec::new();
    for poly in polys {
        let pts = &poly.points;
        let n = pts.len();
        if n < 2 {
            continue;
        }
        for i in 0..n {
            let a = pts[i];
            let b = pts[(i + 1) % n];
            if a.y == b.y || !a.is_finite() || !b.is_finite() {
                continue;
            }
            if a.y < b.y {
                edges.push(Edge {
                    x0: a.x,
                    y0: a.y,
                    x1: b.x,
                    y1: b.y,
                    dir: 1,
                });
            } else {
                edges.push(Edge {
                    x0: b.x,
                    y0: b.y,
                    x1: a.x,
                    y1: a.y,
                    dir: -1,
                });
            }
        }
    }
    edges
}

/// `p` noktasının sarma sayısı (noktadan +x yönüne ışın atılarak).
pub fn winding_number(polys: &[Polyline], p: Vec2) -> i32 {
    collect_edges(polys)
        .iter()
        .filter(|e| e.covers(p.y) && e.x_at(p.y) > p.x)
        .map(|e| e.dir)
        .sum()
}

/// `p` noktası verilen kurala göre dolgunun içinde mi?
pub fn contains(polys: &[Polyline], rule: FillRule, p: Vec2) -> bool {
    rule.is_inside(winding_number(polys, p))
}

#[cfg(test)]
mod tests {
    use super::*;
    use motor_math::Rect;
    use motor_path::Path;

    fn rect_poly(x0: f64, y0: f64, x1: f64, y1: f64) -> Polyline {
        Path::rect(Rect::new(x0, y0, x1, y1)).flatten(0.1).remove(0)
    }

    fn reversed(mut p: Polyline) -> Polyline {
        p.points.reverse();
        p
    }

    #[test]
    fn simple_square() {
        let polys = vec![rect_poly(0.0, 0.0, 10.0, 10.0)];
        assert!(contains(&polys, FillRule::NonZero, Vec2::new(5.0, 5.0)));
        assert!(!contains(&polys, FillRule::NonZero, Vec2::new(15.0, 5.0)));
        assert!(!contains(&polys, FillRule::EvenOdd, Vec2::new(5.0, 15.0)));
    }

    #[test]
    fn nested_same_direction_differs_by_rule() {
        let polys = vec![
            rect_poly(0.0, 0.0, 10.0, 10.0),
            rect_poly(3.0, 3.0, 7.0, 7.0),
        ];
        let c = Vec2::new(5.0, 5.0);
        assert_eq!(winding_number(&polys, c).abs(), 2);
        assert!(contains(&polys, FillRule::NonZero, c));
        assert!(!contains(&polys, FillRule::EvenOdd, c));
    }

    #[test]
    fn nested_opposite_direction_makes_hole() {
        let polys = vec![
            rect_poly(0.0, 0.0, 10.0, 10.0),
            reversed(rect_poly(3.0, 3.0, 7.0, 7.0)),
        ];
        let c = Vec2::new(5.0, 5.0);
        assert_eq!(winding_number(&polys, c), 0);
        assert!(!contains(&polys, FillRule::NonZero, c));
        assert!(contains(&polys, FillRule::NonZero, Vec2::new(1.0, 1.0)));
    }

    #[test]
    fn open_polyline_is_implicitly_closed() {
        let mut p = Path::new();
        p.move_to(Vec2::new(0.0, 0.0))
            .line_to(Vec2::new(10.0, 0.0))
            .line_to(Vec2::new(10.0, 10.0));
        let polys = p.flatten(0.1);
        assert!(contains(&polys, FillRule::NonZero, Vec2::new(8.0, 3.0)));
        assert!(!contains(&polys, FillRule::NonZero, Vec2::new(2.0, 8.0)));
    }
}
