//! Yol dolgusu.
//!
//! - [`winding_number`] / [`contains`]: bir noktanın içeride olup olmadığı (hit-test için de).
//! - [`rasterize`]: CPU referans rasterizer (anti-aliased kapsama maskesi).
//!   Yazılım arka ucu ve GPU çıktısını doğrulamak için "doğru cevap" görevi görür.
//! - [`build_fill_geometry`]: GPU için *stencil-then-cover* geometrisi.
//!
//! Açık alt yollar dolgu sırasında otomatik olarak kapatılır.
#![forbid(unsafe_code)]

mod raster;
mod stencil;
mod winding;

pub use raster::{rasterize, Mask};
pub use stencil::{build_fill_geometry, FillGeometry};
pub use winding::{contains, winding_number};

/// Dolgu kuralı.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum FillRule {
    /// Sarma sayısı 0 değilse içeride.
    #[default]
    NonZero,
    /// Sarma sayısı tekse içeride.
    EvenOdd,
}

impl FillRule {
    pub fn is_inside(self, winding: i32) -> bool {
        match self {
            FillRule::NonZero => winding != 0,
            FillRule::EvenOdd => winding % 2 != 0,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rules() {
        assert!(FillRule::NonZero.is_inside(2));
        assert!(!FillRule::NonZero.is_inside(0));
        assert!(!FillRule::EvenOdd.is_inside(2));
        assert!(FillRule::EvenOdd.is_inside(-1));
        assert!(FillRule::EvenOdd.is_inside(3));
    }
}
