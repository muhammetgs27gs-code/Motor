use crate::FillRule;
use motor_math::{Rect, Vec2};
use motor_path::Polyline;

/// GPU *stencil-then-cover* dolgusu için geometri.
///
/// 1. **Stencil geçişi:** `stencil_vertices` üçgen listesi olarak, renk yazmadan çizilir.
///    - `NonZero`: ön yüzler stencil'i artırır (wrap), arka yüzler azaltır (wrap).
///    - `EvenOdd`: her üçgen stencil'i çevirir (invert).
/// 2. **Cover geçişi:** `cover_quad` (üçgen şeridi sırası) renkle çizilir; stencil testi
///    `!= 0` (EvenOdd için bit 0) olan pikseller boyanır ve stencil sıfırlanır.
///
/// Üçgenler her alt yolun ilk noktasından yelpaze (fan) olarak üretilir; kendini kesen,
/// delikli ve içbükey şekiller ayrıca üçgenlemeye gerek kalmadan doğru dolar.
#[derive(Clone, Debug, PartialEq)]
pub struct FillGeometry {
    pub rule: FillRule,
    pub stencil_vertices: Vec<[f32; 2]>,
    pub cover_quad: [[f32; 2]; 4],
}

fn f32v(v: Vec2) -> [f32; 2] {
    [v.x as f32, v.y as f32]
}

/// Dolgu geometrisini üretir; çizilecek bir şey yoksa `None`.
pub fn build_fill_geometry(polys: &[Polyline], rule: FillRule) -> Option<FillGeometry> {
    let mut verts: Vec<[f32; 2]> = Vec::new();
    let mut bbox = Rect::EMPTY;

    for poly in polys {
        let pts = &poly.points;
        if pts.len() < 3 {
            continue;
        }
        let anchor = pts[0];
        for &p in pts {
            bbox = bbox.union_pt(p);
        }
        for i in 1..pts.len() - 1 {
            verts.push(f32v(anchor));
            verts.push(f32v(pts[i]));
            verts.push(f32v(pts[i + 1]));
        }
    }

    if verts.is_empty() || bbox.is_empty() {
        return None;
    }

    Some(FillGeometry {
        rule,
        stencil_vertices: verts,
        cover_quad: [
            [bbox.x0 as f32, bbox.y0 as f32],
            [bbox.x1 as f32, bbox.y0 as f32],
            [bbox.x0 as f32, bbox.y1 as f32],
            [bbox.x1 as f32, bbox.y1 as f32],
        ],
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use motor_path::Path;

    #[test]
    fn rect_makes_two_triangles() {
        let polys = Path::rect(Rect::new(0.0, 0.0, 4.0, 3.0)).flatten(0.1);
        let g = build_fill_geometry(&polys, FillRule::NonZero).unwrap();
        assert_eq!(g.stencil_vertices.len(), 6);
        assert_eq!(g.cover_quad[0], [0.0, 0.0]);
        assert_eq!(g.cover_quad[3], [4.0, 3.0]);
    }

    #[test]
    fn nothing_to_draw_gives_none() {
        assert!(build_fill_geometry(&[], FillRule::EvenOdd).is_none());
        let mut p = Path::new();
        p.move_to(Vec2::new(0.0, 0.0)).line_to(Vec2::new(1.0, 1.0));
        assert!(build_fill_geometry(&p.flatten(0.1), FillRule::NonZero).is_none());
    }

    #[test]
    fn circle_triangle_count_matches_points() {
        let polys = Path::circle(Vec2::new(0.0, 0.0), 10.0).flatten(0.05);
        let n = polys[0].points.len();
        let g = build_fill_geometry(&polys, FillRule::NonZero).unwrap();
        assert_eq!(g.stencil_vertices.len(), (n - 2) * 3);
    }
}
