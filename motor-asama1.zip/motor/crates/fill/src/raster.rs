use crate::winding::collect_edges;
use crate::FillRule;
use motor_path::Polyline;

/// Tek kanallı kapsama maskesi (0.0 = boş, 1.0 = tam dolu), satır sıralı.
#[derive(Clone, Debug, PartialEq)]
pub struct Mask {
    pub width: usize,
    pub height: usize,
    pub data: Vec<f32>,
}

impl Mask {
    pub fn new(width: usize, height: usize) -> Self {
        Mask {
            width,
            height,
            data: vec![0.0; width * height],
        }
    }

    pub fn get(&self, x: usize, y: usize) -> f32 {
        self.data[y * self.width + x]
    }

    /// Toplam kapsama (≈ alan, piksel cinsinden).
    pub fn sum(&self) -> f64 {
        self.data.iter().map(|&v| v as f64).sum()
    }
}

/// `[xa, xb)` aralığını piksel kapsamlarıyla `acc` satırına ekler (yatayda tam isabetli).
fn add_span(acc: &mut [f32], xa: f64, xb: f64, weight: f32) {
    let xa = xa.max(0.0);
    let xb = xb.min(acc.len() as f64);
    if xb <= xa {
        return;
    }
    let ia = xa.floor() as usize;
    let ib = (xb.ceil() as usize).min(acc.len());
    for (i, a) in acc.iter_mut().enumerate().take(ib).skip(ia) {
        let l = xa.max(i as f64);
        let r = xb.min(i as f64 + 1.0);
        *a += ((r - l) as f32) * weight;
    }
}

/// Düzleştirilmiş yolu `width × height` piksellik bir maskeye çizer.
///
/// Yatayda tam alan kapsamı, dikeyde `subsamples` adet alt tarama çizgisi kullanır
/// (tipik değer: 4–16). Karmaşıklık O(satır · subsamples · kenar); bu bir *referans*
/// uygulamadır, üretim yolu GPU'dur.
pub fn rasterize(
    polys: &[Polyline],
    rule: FillRule,
    width: usize,
    height: usize,
    subsamples: u32,
) -> Mask {
    let mut mask = Mask::new(width, height);
    let edges = collect_edges(polys);
    if edges.is_empty() || width == 0 || height == 0 {
        return mask;
    }

    let s = subsamples.max(1) as usize;
    let weight = 1.0 / s as f32;
    let ymin = edges.iter().map(|e| e.y0).fold(f64::INFINITY, f64::min);
    let ymax = edges.iter().map(|e| e.y1).fold(f64::NEG_INFINITY, f64::max);
    let row0 = ymin.floor().max(0.0) as usize;
    let row1 = (ymax.ceil().max(0.0) as usize).min(height);

    let mut xs: Vec<(f64, i32)> = Vec::new();
    for row in row0..row1 {
        let acc = &mut mask.data[row * width..(row + 1) * width];
        for k in 0..s {
            let y = row as f64 + (k as f64 + 0.5) / s as f64;
            xs.clear();
            for e in &edges {
                if e.covers(y) {
                    xs.push((e.x_at(y), e.dir));
                }
            }
            if xs.len() < 2 {
                continue;
            }
            xs.sort_by(|a, b| a.0.total_cmp(&b.0));
            let mut w = 0;
            for pair in xs.windows(2) {
                w += pair[0].1;
                if rule.is_inside(w) {
                    add_span(acc, pair[0].0, pair[1].0, weight);
                }
            }
        }
    }
    mask
}

#[cfg(test)]
mod tests {
    use super::*;
    use motor_math::{Rect, Vec2};
    use motor_path::Path;

    fn rect_polys(x0: f64, y0: f64, x1: f64, y1: f64) -> Vec<Polyline> {
        Path::rect(Rect::new(x0, y0, x1, y1)).flatten(0.1)
    }

    fn near(a: f64, b: f64, eps: f64) -> bool {
        (a - b).abs() < eps
    }

    #[test]
    fn pixel_aligned_square() {
        let m = rasterize(&rect_polys(1.0, 1.0, 3.0, 3.0), FillRule::NonZero, 4, 4, 4);
        assert!(near(m.get(1, 1) as f64, 1.0, 1e-5));
        assert!(near(m.get(2, 2) as f64, 1.0, 1e-5));
        assert!(near(m.get(0, 0) as f64, 0.0, 1e-5));
        assert!(near(m.get(3, 3) as f64, 0.0, 1e-5));
        assert!(near(m.sum(), 4.0, 1e-4));
    }

    #[test]
    fn half_pixel_coverage() {
        let m = rasterize(&rect_polys(0.5, 0.0, 1.5, 1.0), FillRule::NonZero, 2, 1, 4);
        assert!(near(m.get(0, 0) as f64, 0.5, 1e-5));
        assert!(near(m.get(1, 0) as f64, 0.5, 1e-5));
    }

    #[test]
    fn nested_rules_change_area() {
        let mut polys = rect_polys(0.0, 0.0, 8.0, 8.0);
        polys.extend(rect_polys(2.0, 2.0, 6.0, 6.0));
        let nz = rasterize(&polys, FillRule::NonZero, 8, 8, 4);
        let eo = rasterize(&polys, FillRule::EvenOdd, 8, 8, 4);
        assert!(near(nz.sum(), 64.0, 1e-3));
        assert!(near(eo.sum(), 48.0, 1e-3));
    }

    #[test]
    fn circle_area_is_close() {
        let polys = Path::circle(Vec2::new(32.0, 32.0), 20.0).flatten(0.05);
        let m = rasterize(&polys, FillRule::NonZero, 64, 64, 16);
        let expected = std::f64::consts::PI * 400.0;
        assert!((m.sum() - expected).abs() / expected < 0.01);
    }

    #[test]
    fn clipped_at_image_bounds() {
        let m = rasterize(&rect_polys(-5.0, -5.0, 2.0, 2.0), FillRule::NonZero, 4, 4, 4);
        assert!(near(m.sum(), 4.0, 1e-4));
        let empty = rasterize(&[], FillRule::NonZero, 4, 4, 4);
        assert!(near(empty.sum(), 0.0, 1e-12));
    }
}
