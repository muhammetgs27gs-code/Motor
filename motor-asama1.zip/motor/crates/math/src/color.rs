/// sRGB renk, düz (premultiplied olmayan) alfa. Bileşenler 0..=1.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Color {
    pub r: f32,
    pub g: f32,
    pub b: f32,
    pub a: f32,
}

fn srgb_to_linear(c: f32) -> f32 {
    if c <= 0.04045 {
        c / 12.92
    } else {
        ((c + 0.055) / 1.055).powf(2.4)
    }
}

fn linear_to_srgb(c: f32) -> f32 {
    if c <= 0.003_130_8 {
        c * 12.92
    } else {
        1.055 * c.powf(1.0 / 2.4) - 0.055
    }
}

impl Color {
    pub const TRANSPARENT: Color = Color::rgba(0.0, 0.0, 0.0, 0.0);
    pub const BLACK: Color = Color::rgba(0.0, 0.0, 0.0, 1.0);
    pub const WHITE: Color = Color::rgba(1.0, 1.0, 1.0, 1.0);

    pub const fn rgba(r: f32, g: f32, b: f32, a: f32) -> Self {
        Color { r, g, b, a }
    }

    pub fn from_rgba8(r: u8, g: u8, b: u8, a: u8) -> Self {
        Color::rgba(
            r as f32 / 255.0,
            g as f32 / 255.0,
            b as f32 / 255.0,
            a as f32 / 255.0,
        )
    }

    /// `0xRRGGBB` biçiminden opak renk.
    pub fn from_hex(hex: u32) -> Self {
        Color::from_rgba8(
            ((hex >> 16) & 0xff) as u8,
            ((hex >> 8) & 0xff) as u8,
            (hex & 0xff) as u8,
            255,
        )
    }

    pub fn with_alpha(self, a: f32) -> Self {
        Color { a, ..self }
    }

    /// Alfa ile çarpılmış `[r, g, b, a]`.
    pub fn premultiplied(self) -> [f32; 4] {
        [self.r * self.a, self.g * self.a, self.b * self.a, self.a]
    }

    /// RGB'yi doğrusal uzaya çevirir (alfa değişmez).
    pub fn to_linear(self) -> Color {
        Color::rgba(
            srgb_to_linear(self.r),
            srgb_to_linear(self.g),
            srgb_to_linear(self.b),
            self.a,
        )
    }

    /// Doğrusal RGB'yi sRGB'ye çevirir (alfa değişmez).
    pub fn to_srgb(self) -> Color {
        Color::rgba(
            linear_to_srgb(self.r),
            linear_to_srgb(self.g),
            linear_to_srgb(self.b),
            self.a,
        )
    }

    pub fn lerp(self, o: Color, t: f32) -> Color {
        Color::rgba(
            self.r + (o.r - self.r) * t,
            self.g + (o.g - self.g) * t,
            self.b + (o.b - self.b) * t,
            self.a + (o.a - self.a) * t,
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn hex_parses() {
        let c = Color::from_hex(0xff8000);
        assert!((c.r - 1.0).abs() < 1e-6);
        assert!((c.g - 128.0 / 255.0).abs() < 1e-6);
        assert_eq!(c.b, 0.0);
        assert_eq!(c.a, 1.0);
    }

    #[test]
    fn linear_srgb_roundtrip() {
        let c = Color::rgba(0.2, 0.5, 0.9, 0.7);
        let r = c.to_linear().to_srgb();
        assert!((r.r - c.r).abs() < 1e-5 && (r.g - c.g).abs() < 1e-5 && (r.b - c.b).abs() < 1e-5);
        assert_eq!(r.a, c.a);
    }

    #[test]
    fn premultiply() {
        let p = Color::rgba(1.0, 0.5, 0.0, 0.5).premultiplied();
        assert_eq!(p, [0.5, 0.25, 0.0, 0.5]);
    }
}
