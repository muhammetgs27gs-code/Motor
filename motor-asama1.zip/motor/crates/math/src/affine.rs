use crate::{Rect, Vec2};
use core::ops::Mul;

/// 2D afin dönüşüm.
///
/// ```text
/// x' = a*x + c*y + e
/// y' = b*x + d*y + f
/// ```
///
/// Çarpım sırası: `A * B`, önce `B`'yi sonra `A`'yı uygular.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Affine {
    pub a: f64,
    pub b: f64,
    pub c: f64,
    pub d: f64,
    pub e: f64,
    pub f: f64,
}

impl Affine {
    pub const IDENTITY: Affine = Affine {
        a: 1.0,
        b: 0.0,
        c: 0.0,
        d: 1.0,
        e: 0.0,
        f: 0.0,
    };

    pub const fn new(a: f64, b: f64, c: f64, d: f64, e: f64, f: f64) -> Self {
        Affine { a, b, c, d, e, f }
    }

    pub fn translate(v: Vec2) -> Self {
        Affine::new(1.0, 0.0, 0.0, 1.0, v.x, v.y)
    }

    pub fn scale(sx: f64, sy: f64) -> Self {
        Affine::new(sx, 0.0, 0.0, sy, 0.0, 0.0)
    }

    pub fn scale_uniform(s: f64) -> Self {
        Affine::scale(s, s)
    }

    /// Radyan cinsinden döndürme (y aşağı eksende saat yönü, y yukarı eksende saat yönünün tersi).
    pub fn rotate(theta: f64) -> Self {
        let (s, c) = theta.sin_cos();
        Affine::new(c, s, -s, c, 0.0, 0.0)
    }

    pub fn rotate_about(theta: f64, center: Vec2) -> Self {
        Affine::translate(center) * Affine::rotate(theta) * Affine::translate(-center)
    }

    pub fn skew(sx: f64, sy: f64) -> Self {
        Affine::new(1.0, sy.tan(), sx.tan(), 1.0, 0.0, 0.0)
    }

    /// Bu dönüşümden SONRA `t` ötelemesini uygular.
    pub fn then_translate(self, v: Vec2) -> Self {
        Affine::translate(v) * self
    }

    /// Bu dönüşümden SONRA ölçekleme uygular.
    pub fn then_scale(self, sx: f64, sy: f64) -> Self {
        Affine::scale(sx, sy) * self
    }

    pub fn determinant(&self) -> f64 {
        self.a * self.d - self.b * self.c
    }

    pub fn is_invertible(&self) -> bool {
        let det = self.determinant();
        det.is_finite() && det.abs() > 1e-300
    }

    pub fn inverse(&self) -> Option<Affine> {
        if !self.is_invertible() {
            return None;
        }
        let inv = 1.0 / self.determinant();
        Some(Affine::new(
            self.d * inv,
            -self.b * inv,
            -self.c * inv,
            self.a * inv,
            (self.c * self.f - self.d * self.e) * inv,
            (self.b * self.e - self.a * self.f) * inv,
        ))
    }

    /// Noktayı dönüştürür (öteleme dahil).
    pub fn transform_point(&self, p: Vec2) -> Vec2 {
        Vec2::new(
            self.a * p.x + self.c * p.y + self.e,
            self.b * p.x + self.d * p.y + self.f,
        )
    }

    /// Vektörü dönüştürür (öteleme hariç).
    pub fn transform_vector(&self, v: Vec2) -> Vec2 {
        Vec2::new(self.a * v.x + self.c * v.y, self.b * v.x + self.d * v.y)
    }

    /// Dikdörtgenin dönüşmüş halinin sınırlayıcı kutusu.
    pub fn transform_rect_bbox(&self, r: &Rect) -> Rect {
        if r.is_empty() {
            return Rect::EMPTY;
        }
        r.corners()
            .iter()
            .fold(Rect::EMPTY, |acc, &p| acc.union_pt(self.transform_point(p)))
    }

    /// GPU için f32 katsayılar: `[a, b, c, d, e, f]`.
    pub fn to_f32_coeffs(&self) -> [f32; 6] {
        [
            self.a as f32,
            self.b as f32,
            self.c as f32,
            self.d as f32,
            self.e as f32,
            self.f as f32,
        ]
    }
}

impl Default for Affine {
    fn default() -> Self {
        Affine::IDENTITY
    }
}

impl Mul<Affine> for Affine {
    type Output = Affine;
    fn mul(self, o: Affine) -> Affine {
        Affine::new(
            self.a * o.a + self.c * o.b,
            self.b * o.a + self.d * o.b,
            self.a * o.c + self.c * o.d,
            self.b * o.c + self.d * o.d,
            self.a * o.e + self.c * o.f + self.e,
            self.b * o.e + self.d * o.f + self.f,
        )
    }
}

impl Mul<Vec2> for Affine {
    type Output = Vec2;
    fn mul(self, p: Vec2) -> Vec2 {
        self.transform_point(p)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use core::f64::consts::FRAC_PI_2;

    fn close(a: Vec2, b: Vec2) -> bool {
        (a - b).length() < 1e-9
    }

    #[test]
    fn inverse_roundtrip() {
        let m = Affine::translate(Vec2::new(3.0, 4.0))
            * Affine::rotate(0.7)
            * Affine::scale(2.0, 3.0);
        let inv = m.inverse().unwrap();
        let p = Vec2::new(1.5, -2.0);
        assert!(close(inv * (m * p), p));
    }

    #[test]
    fn rotate_quarter_turn() {
        let p = Affine::rotate(FRAC_PI_2) * Vec2::new(1.0, 0.0);
        assert!(close(p, Vec2::new(0.0, 1.0)));
    }

    #[test]
    fn multiplication_order() {
        // Önce ölçekle, sonra ötele.
        let m = Affine::translate(Vec2::new(10.0, 0.0)) * Affine::scale_uniform(2.0);
        assert!(close(m * Vec2::new(1.0, 1.0), Vec2::new(12.0, 2.0)));
        let m2 = Affine::scale_uniform(2.0).then_translate(Vec2::new(10.0, 0.0));
        assert_eq!(m, m2);
    }

    #[test]
    fn singular_has_no_inverse() {
        assert!(Affine::scale(0.0, 1.0).inverse().is_none());
    }

    #[test]
    fn rotate_about_keeps_center_fixed() {
        let c = Vec2::new(5.0, 5.0);
        let m = Affine::rotate_about(1.2, c);
        assert!(close(m * c, c));
    }

    #[test]
    fn rect_bbox_of_rotation() {
        let r = Rect::new(0.0, 0.0, 2.0, 1.0);
        let b = Affine::rotate(FRAC_PI_2).transform_rect_bbox(&r);
        assert!((b.width() - 1.0).abs() < 1e-9);
        assert!((b.height() - 2.0).abs() < 1e-9);
    }
}
