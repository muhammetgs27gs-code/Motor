//! Motorun temel matematik türleri.
//!
//! Geometri `f64` ile tutulur; GPU'ya giderken `f32`'ye çevrilir.
#![forbid(unsafe_code)]

mod affine;
mod color;
mod rect;
mod vec2;

pub use affine::Affine;
pub use color::Color;
pub use rect::Rect;
pub use vec2::Vec2;
