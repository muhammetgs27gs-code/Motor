use crate::Vec2;

/// Eksenlere hizalı dikdörtgen. `x0 <= x1`, `y0 <= y1` beklenir.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Rect {
    pub x0: f64,
    pub y0: f64,
    pub x1: f64,
    pub y1: f64,
}

impl Rect {
    /// Birleşim (union) için başlangıç değeri: boş/ters dikdörtgen.
    /// `width()`/`height()` bunda negatif sonsuz döner; önce `is_empty()` kontrol edin.
    pub const EMPTY: Rect = Rect {
        x0: f64::INFINITY,
        y0: f64::INFINITY,
        x1: f64::NEG_INFINITY,
        y1: f64::NEG_INFINITY,
    };

    pub const fn new(x0: f64, y0: f64, x1: f64, y1: f64) -> Self {
        Rect { x0, y0, x1, y1 }
    }

    /// İki köşeden, sıralamayı düzelterek oluşturur.
    pub fn from_points(a: Vec2, b: Vec2) -> Self {
        Rect::new(a.x.min(b.x), a.y.min(b.y), a.x.max(b.x), a.y.max(b.y))
    }

    pub fn from_origin_size(origin: Vec2, size: Vec2) -> Self {
        Rect::from_points(origin, origin + size)
    }

    pub fn is_empty(&self) -> bool {
        self.x0 > self.x1 || self.y0 > self.y1
    }

    pub fn width(&self) -> f64 {
        self.x1 - self.x0
    }

    pub fn height(&self) -> f64 {
        self.y1 - self.y0
    }

    pub fn area(&self) -> f64 {
        self.width() * self.height()
    }

    pub fn center(&self) -> Vec2 {
        Vec2::new((self.x0 + self.x1) * 0.5, (self.y0 + self.y1) * 0.5)
    }

    pub fn corners(&self) -> [Vec2; 4] {
        [
            Vec2::new(self.x0, self.y0),
            Vec2::new(self.x1, self.y0),
            Vec2::new(self.x1, self.y1),
            Vec2::new(self.x0, self.y1),
        ]
    }

    pub fn contains(&self, p: Vec2) -> bool {
        p.x >= self.x0 && p.x <= self.x1 && p.y >= self.y0 && p.y <= self.y1
    }

    pub fn intersects(&self, o: &Rect) -> bool {
        self.x0 <= o.x1 && o.x0 <= self.x1 && self.y0 <= o.y1 && o.y0 <= self.y1
    }

    pub fn union(&self, o: &Rect) -> Rect {
        Rect::new(
            self.x0.min(o.x0),
            self.y0.min(o.y0),
            self.x1.max(o.x1),
            self.y1.max(o.y1),
        )
    }

    pub fn union_pt(&self, p: Vec2) -> Rect {
        Rect::new(
            self.x0.min(p.x),
            self.y0.min(p.y),
            self.x1.max(p.x),
            self.y1.max(p.y),
        )
    }

    pub fn intersection(&self, o: &Rect) -> Option<Rect> {
        let r = Rect::new(
            self.x0.max(o.x0),
            self.y0.max(o.y0),
            self.x1.min(o.x1),
            self.y1.min(o.y1),
        );
        if r.is_empty() {
            None
        } else {
            Some(r)
        }
    }

    pub fn inflate(&self, dx: f64, dy: f64) -> Rect {
        Rect::new(self.x0 - dx, self.y0 - dy, self.x1 + dx, self.y1 + dy)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn union_with_empty_is_identity() {
        let r = Rect::new(1.0, 2.0, 3.0, 4.0);
        assert_eq!(Rect::EMPTY.union(&r), r);
        assert!(Rect::EMPTY.is_empty());
    }

    #[test]
    fn intersection_works() {
        let a = Rect::new(0.0, 0.0, 10.0, 10.0);
        let b = Rect::new(5.0, 5.0, 15.0, 15.0);
        assert_eq!(a.intersection(&b), Some(Rect::new(5.0, 5.0, 10.0, 10.0)));
        let c = Rect::new(20.0, 20.0, 30.0, 30.0);
        assert_eq!(a.intersection(&c), None);
        assert!(!a.intersects(&c));
    }

    #[test]
    fn contains_point() {
        let r = Rect::new(0.0, 0.0, 2.0, 2.0);
        assert!(r.contains(Vec2::new(1.0, 1.0)));
        assert!(!r.contains(Vec2::new(3.0, 1.0)));
    }
}
