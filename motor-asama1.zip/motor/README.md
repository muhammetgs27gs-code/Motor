# Motor — 2D çizim motoru

Güçlü, genişletilebilir bir 2D çizim motoru. Üzerine araçlar, formatlar ve uygulamalar eklenti olarak biner.

## Aşama 1 (çekirdek) — ilerleme
- [x] Proje iskeleti, CI
- [x] `motor-math`: Vec2, Affine, Rect, Color
- [x] `motor-path`: Bézier türleri, Path modeli, bounding box, flatten
- [x] `motor-fill`: dolgu kuralları (non-zero / even-odd), winding hesabı, CPU referans rasterizer, GPU stencil-then-cover geometrisi
- [ ] Stroke (uç/birleşim tipleri, kesik çizgi)
- [ ] Boyama (gradyan, karışım modları)
- [ ] Anti-aliasing, clip, render arka ucu soyutlaması
- [ ] Demo uygulama

## Kurallar
- Geometri CPU tarafında `f64`; GPU'ya giderken `f32`'ye çevrilir.
- Affine çarpımı: `A * B` önce B'yi, sonra A'yı uygular.

## Çalıştırma
    cargo test --workspace
